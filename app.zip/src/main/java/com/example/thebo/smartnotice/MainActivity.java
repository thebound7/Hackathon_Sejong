package com.example.thebo.smartnotice;

import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import android.view.View.OnClickListener;
import android.view.View;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private TextView mTextMessage;
    private String htmlPageUrl = "http://board.sejong.ac.kr/boardlist.do?bbsConfigFK=333";
    private TextView textviewHtmlDocument;
    private String htmlContentInStringFormat;
    private LinearLayout linear;
    private int departcode;
    private MainActivity main;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            linear = (LinearLayout)findViewById(R.id.loading);
            linear.removeAllViewsInLayout();
            JsoupAsyncTask jsoupAsyncTask = new JsoupAsyncTask(linear, main);

            //TODO : 데이터 베이스에서 departcode 읽어옴.

            switch (item.getItemId()) {
                case R.id.navigation_1:
                    htmlPageUrl = "http://board.sejong.ac.kr/boardlist.do?bbsConfigFK=333";

                    addText( createText( "", "", 20 ), linear );
                    addText( createText( "", "", 20 ), linear );
                    addText( createText( "", "", 20 ), linear );
                    addText( createText( "", "", 20 ), linear );
                    jsoupAsyncTask.execute();
                    return true;
                case R.id.navigation_2:
                    departcode = 35;

                    // 여기서 부터는 학과별로 페이지 소스가 다름. 정보보호학과를 기준으로 작성.
                    switch( departcode ) {
                        case 35: // 정보보호학과
                            htmlPageUrl = "http://home.sejong.ac.kr/bbs/bbslist.do?forword=&wslID=isdpt&bbsid=571";
                            break;
                        case 1:
                            htmlPageUrl = "http://dasan.sejong.ac.kr/~civil/community01.php";
                            break;
                        case 2:
                            htmlPageUrl = "http://ae.sejong.ac.kr/website/03ae03.php";
                            break;
                        case 3:
                            htmlPageUrl = "http://arch.sejong.ac.kr/events/notice";
                            break;
                        case 4:
                            htmlPageUrl = "http://home.sejong.ac.kr/~mnadpt/5.html";
                            break;
                        case 5:
                            htmlPageUrl = "http://home.sejong.ac.kr/~entdpt/5.html";
                            break;
                        case 6:
                            htmlPageUrl = "http://home.sejong.ac.kr/~edudpt/";
                            break;
                        case 7:
                            htmlPageUrl = "http://home.sejong.ac.kr/~dsedpt/25.html";
                            break;
                        case 8:
                            htmlPageUrl = "http://home.sejong.ac.kr/~kordpt/10.html";
                            break;
                        case 9:
                            htmlPageUrl = "http://home.sejong.ac.kr/~medpt/13.html";
                            break;
                        case 10:
                            htmlPageUrl = "http://home.sejong.ac.kr/~nanodpt/5.html";
                            break;
                        case 11:
                            htmlPageUrl = "http://home.sejong.ac.kr/~lliberal/5.html";
                            break;
                        case 12:
                            htmlPageUrl = " ";
                            break;
                        case 13:
                            htmlPageUrl = "http://home.sejong.ac.kr/~design/5.html";
                            break;
                        case 14:
                            htmlPageUrl = "http://home.sejong.ac.kr/~phyastrodpt/";
                            break;
                        case 15:
                            htmlPageUrl = "http://home.sejong.ac.kr/~anitec/13.html";
                            break;
                        case 16:
                            htmlPageUrl = "http://home.sejong.ac.kr/~dancedpt/5.html";
                            break;
                        case 17:
                            htmlPageUrl = "http://home.sejong.ac.kr/~plantdpt/";
                            break;
                        case 18:
                            htmlPageUrl = "http://home.sejong.ac.kr/~bioscidpt/";
                            break;
                        case 19:
                            htmlPageUrl = "http://home.sejong.ac.kr/~iddpt/15.html";
                            break;
                        case 20:
                            htmlPageUrl = "http://home.sejong.ac.kr/~digitdpt/";
                            break;
                        case 21:
                            htmlPageUrl = " ";
                            break;
                        case 22:
                            htmlPageUrl = "http://home.sejong.ac.kr/~fooddpt/";
                            break;
                        case 23:
                            htmlPageUrl = "http://home.sejong.ac.kr/~nnbdpt/5.html";
                            break;
                        case 24:
                            htmlPageUrl = "http://home.sejong.ac.kr/~histdpt/6.html";
                            break;
                        case 25:
                            htmlPageUrl = "http://home.sejong.ac.kr/~engdpt/5.html";
                            break;
                        case 26:
                            htmlPageUrl = "";
                            break;
                        case 27:
                            htmlPageUrl ="http://home.sejong.ac.kr/~energydpt/5.html";
                            break;
                        case 28:
                            htmlPageUrl ="http://home.sejong.ac.kr/~musicdpt/";
                            break;
                        case 29:
                            htmlPageUrl = " ";
                            break;
                        case 30:
                            htmlPageUrl = "http://japan.sejong.ac.kr/dpt_notice";
                            break;
                        case 31:
                            htmlPageUrl = "http://www.htmsejong.com/html/notice_2.asp";
                            break;
                        case 32:
                            htmlPageUrl = "http://home.sejong.ac.kr/~nuedpt/5.html";
                            break;
                        case 33:
                            htmlPageUrl = "http://home.sejong.ac.kr/~electrodpt/22.html";
                            break;
                        case 34:
                            htmlPageUrl = "http://home.sejong.ac.kr/~cndpt/14.html";
                            break;
                        case 36:
                            htmlPageUrl = "http://home.sejong.ac.kr/~soime/5.html";
                            break;
                        case 37:
                            htmlPageUrl = "http://home.sejong.ac.kr/~pedpt/5.html";
                            break;
                        case 38:
                            htmlPageUrl = "http://ce.sejong.ac.kr/itinformation";
                            break;
                        case 39:
                            htmlPageUrl = "http://sjfd.sejong.ac.kr/xe/board1";
                            break;
                        case 40:
                            htmlPageUrl = "http://home.sejong.ac.kr/~aerosysdpt/21.html";
                            break;
                        case 41:
                            htmlPageUrl = "http://home.sejong.ac.kr/~aerodpt/15.html";
                            break;
                        case 42:
                            htmlPageUrl = "http://home.sejong.ac.kr/~admdpt/5.html";
                            break;
                        case 43:
                            htmlPageUrl = " ";
                            break;
                        case 44:
                            htmlPageUrl = "http://www.htmsejong.com/html/notice_2.asp";
                            break;
                        case 45:
                            htmlPageUrl = "http://www.htmsejong.com/html/notice_2.asp";
                            break;
                        case 46:
                            htmlPageUrl = "http://www.htmsejong.com/html/notice_2.asp";
                            break;
                        case 47:
                            htmlPageUrl = "http://home.sejong.ac.kr/~chemdpt/11.html";
                            break;
                        case 48:
                            htmlPageUrl = "http://home.sejong.ac.kr/~eegdpt/";
                            break;
                        case 49:
                            htmlPageUrl = "http://home.sejong.ac.kr/~picdpt/";
                            break;
                    }

                    addText( createText( "", "", 20 ), linear );
                    addText( createText( "", "", 20 ), linear );
                    addText( createText( "", "", 20 ), linear );
                    addText( createText( "", "", 20 ), linear );
                    jsoupAsyncTask.execute();
                    return true;
                case R.id.navigation_3: // 환경설정
                    addImage( createImage(R.drawable.warning), linear );
                    //startActivity(new Intent(main, DepartmentActivity.class));
                    return true;
            }
            return false;
        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        main = this;
        startActivity(new Intent(this, LoadingActivity.class));

        linear = (LinearLayout)findViewById(R.id.loading);

        addText( createText( "", "", 20 ), linear );
        addText( createText( "", "", 20 ), linear );
        addText( createText( "", "", 20 ), linear );
        addText( createText( "", "", 20 ), linear );

        JsoupAsyncTask jsoupAsyncTask = new JsoupAsyncTask(linear, this);
        jsoupAsyncTask.execute();
    }

    private ImageView createImage(int img) {
        ImageView imgv = new ImageView(this);
        imgv.setImageResource(img);
        imgv.setScaleType(ImageView.ScaleType.CENTER);
        imgv.bringToFront();
        //imgv.setLayoutDirection(View.LAYOUT_DIRECTION_INHERIT);
        return imgv;
    }

    private void addImage(ImageView imgv, LinearLayout linear) {
        linear.addView(imgv);
    }

    private TextView createText(String text, String url, int size) {
        TextView txt = (TextView) new TextView(this);
        //txt.setText(Html.fromHtml("<a href=\""+url+"\" style=\"text-decoration:none\">"+text+"</a>"));
        txt.setText(Html.fromHtml("<a href=\""+url+"\" style=\"color: white\">"+text+"</a>"));
        txt.setMovementMethod(LinkMovementMethod.getInstance());
        txt.setTextSize(size);
        txt.setMaxLines(1);
        txt.setEllipsize(TextUtils.TruncateAt.END);
        return txt;
    }

    private void addText(TextView text, LinearLayout linear) {
        linear.addView(text);
    }

    private Button createButton(String text, final String url) {
        LinearLayout linear = (LinearLayout)findViewById(R.id.container);
        final Button btn = new Button(this);
        btn.setText(text);
        btn.setAlpha(0);
        //btn.setBackgroundColor(0x00FF0000);
        //btn.setBackgroundResource(R.drawable.button);
        //btn.set
        btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v)
            {
                btn.setBackgroundResource(R.drawable.button_touch);
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            }
        });
        return btn;
    }

    private void addButton(Button btn, LinearLayout linear) {
        linear.addView(btn);
    }

    private class JsoupAsyncTask extends AsyncTask<Void, Void, Void> {

        private LinearLayout linear;
        private MainActivity main;
        private Dual el[] = new Dual[100];
        public JsoupAsyncTask(LinearLayout linear, MainActivity main) {
            this.linear = linear;
            this.main = main;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                htmlContentInStringFormat = "";
                Document doc = Jsoup.connect(htmlPageUrl).get();
                //Elements links1 = doc.select("td.subject");
                Elements links1 = doc.select("td.subject > a");
                int i = 0;
                for (Element link : links1) {
                    el[i++] = new Dual(link.text().trim(), link.attr("abs:href")); // 앞에 값은 이름, 뒤에 값은 주소
                }

            } catch (IOException e) {
                htmlContentInStringFormat = "인터넷을 켜고 다시 시도해 주십시오.";
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            for ( int i = 0; i < 10; i++ ) {
                addText(createText("", "", 11), linear);
                addText(createText(el[i].getFirst(), el[i].getSecond(), 20), linear);
            }
            //addButton( createButton( el[i].getFirst(), el[i].getSecond() ), linear );
        }
    }

}
