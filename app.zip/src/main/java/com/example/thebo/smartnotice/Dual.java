package com.example.thebo.smartnotice;

/**
 * Created by 정재우 on 2017-06-26.
 */

public class Dual {
    private String a, b;

    public Dual( String a, String b ) {
        this.a = a;
        this.b = b;
    }

    public String getFirst() {
        return a;
    }

    public void setFirst(String n) {
        this.a = n;
    }

    public String getSecond() {
        return b;
    }

    public void setSecond(String n) {
        this.b = n;
    }
}
