package com.example.thebo.smartnotice;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class DepartmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final CheckBox cb1 = (CheckBox) findViewById(R.id.checkBox1);
        final CheckBox cb2 = (CheckBox) findViewById(R.id.checkBox2);
        final CheckBox cb3 = (CheckBox) findViewById(R.id.checkBox3);
        final CheckBox cb4 = (CheckBox) findViewById(R.id.checkBox4);
        final CheckBox cb5 = (CheckBox) findViewById(R.id.checkBox5);
        final CheckBox cb6 = (CheckBox) findViewById(R.id.checkBox6);
        final CheckBox cb7 = (CheckBox) findViewById(R.id.checkBox7);
        final CheckBox cb8 = (CheckBox) findViewById(R.id.checkBox8);


            /*Button b = (Button)findViewById(R.id.button1);
            final TextView tv = (TextView)findViewById(R.id.textView2);

            SharedPreferences pref = getSharedPreferences( "pref" , MODE_PRIVATE);
            final SharedPreferences.Editor ed = pref.edit();
            ed.putInt( "age" , 39 );

            ed.commit();

            b.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if(cb1.isChecked() == true) ed.putInt( cb1.getText().toString(), 1 );
                    if(cb2.isChecked() == true) ed.putInt( cb2.getText().toString(), 1 );
                    if(cb3.isChecked() == true) ed.putInt( cb3.getText().toString(), 1 );
                    if(cb4.isChecked() == true) ed.putInt( cb4.getText().toString(), 1 );
                    if(cb5.isChecked() == true) ed.putInt( cb5.getText().toString(), 1 );
                    if(cb6.isChecked() == true) ed.putInt( cb6.getText().toString(), 1 );
                    if(cb7.isChecked() == true) ed.putInt( cb7.getText().toString(), 1 );
                    if(cb8.isChecked() == true) ed.putInt( cb8.getText().toString(), 1 );
                    ed.commit();
                } // end onClick
            }); // end setOnClickListener
        */
    } // end onCreate()
}

